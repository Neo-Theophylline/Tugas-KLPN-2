<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="table-responsive pt-3">
                    <table class="table table-striped project-orders-table">
                        <thead>
                            <tr>
                                <th style="width: 10%;">ID</th>
                                <th style="width: 20%;">Photo</th>
                                <th style="width: 15%;">Title</th>
                                <th style="width: 35%;">Subtitle</th>
                                <th style="width: 20%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"
                                        style="max-width: 80px; word-break: break-word; overflow-wrap: break-word; white-space: normal;">
                                        <?php echo e($hero->id); ?>

                                    </td>

                                    <td class="align-middle">
                                        <img style="object-fit:cover; border-radius:0; width:auto; height:100px;"
                                            src="<?php echo e(asset('storage/' . $hero->photo)); ?>" alt="Photo">
                                    </td>

                                    <td class="align-middle"
                                        style="max-width: 150px; word-break: break-word; overflow-wrap: break-word; white-space: normal;">
                                        <?php echo e($hero->title); ?>

                                    </td>

                                    <td class="align-middle"
                                        style="max-width: 250px; word-break: break-word; overflow-wrap: break-word; white-space: normal;">
                                        <?php echo e($hero->subtitle); ?>

                                    </td>

                                    <td class="align-middle">
                                        
                                        <div class="d-flex align-items-center justify-content-center mb-2">
                                            
                                            <a href="<?php echo e(route('admin.hero.edit', $hero->id)); ?>"
                                                class="btn btn-success btn-sm d-flex align-items-center mr-2">
                                                Edit <i class="typcn typcn-edit ml-1"></i>
                                            </a>

                                            
                                            <form action="<?php echo e(route('admin.hero.destroy', $hero->id)); ?>" method="POST"
                                                onsubmit="return confirm('Yakin mau hapus?');" class="mb-0">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="btn btn-danger btn-sm d-flex align-items-center">
                                                    Delete <i class="typcn typcn-delete-outline ml-1"></i>
                                                </button>
                                            </form>
                                        </div>

                                        
                                        <div class="d-flex justify-content-center">
                                            <label class="toggle-switch toggle-switch-success mb-0">
                                                <input type="checkbox" checked>
                                                <span class="toggle-slider round"></span>
                                            </label>
                                        </div>
                                        </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td colspan="5" class="text-center">
                                    
                                    <a href="<?php echo e(route('admin.hero.create')); ?>" class="btn btn-success btn-icon-text">
                                        Create <i class="typcn typcn-edit ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\project\Tugas-KLPN-2\Project-GAKKOU\resources\views\page\backend\Hero\index.blade.php ENDPATH**/ ?>