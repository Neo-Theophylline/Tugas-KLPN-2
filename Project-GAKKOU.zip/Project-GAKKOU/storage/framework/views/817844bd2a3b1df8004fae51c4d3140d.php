
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="table-responsive pt-3">
                    <table class="table table-striped project-orders-table">
                        <thead>
                            <tr>
                                <th style="width: 10%;">ID</th>
                                <th style="width: 35%;">nama</th>
                                <th style="width: 35%;">email</th>
                                <th style="width: 20%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"
                                        style="max-width: 80px; word-break: break-word; overflow-wrap: break-word; white-space: normal;">
                                        <?php echo e($auth->id); ?>

                                    </td>

                                    <td class="align-middle"
                                        style="max-width: 80px; word-break: break-word; overflow-wrap: break-word; white-space: normal;">
                                        <?php echo e($auth->name); ?>

                                    </td>

                                    <td class="align-middle"
                                        style="max-width: 150px; word-break: break-word; overflow-wrap: break-word; white-space: normal;">
                                        <?php echo e($auth->email); ?>

                                    </td>

                                    <td class="align-middle">
                                        
                                        <div class="d-flex align-items-center justify-content-center mb-2">
                                            
                                            <a href="<?php echo e(route('users.edit', $auth->id)); ?>"
                                                class="btn btn-success btn-sm d-flex align-items-center mr-2">
                                                Edit <i class="typcn typcn-edit ml-1"></i>
                                            </a>

                                            
                                            <form action="<?php echo e(route('users.destroy', $auth->id  )); ?>" method="POST"
                                                onsubmit="return confirm('Yakin mau hapus?');" class="mb-0">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="btn btn-danger btn-sm d-flex align-items-center">
                                                    Delete <i class="typcn typcn-delete-outline ml-1"></i>
                                                </button>
                                            </form>
                                        </div>

                                        
                                        <div class="d-flex justify-content-center">
                                            <label class="toggle-switch toggle-switch-success mb-0">
                                                <input type="checkbox" checked>
                                                <span class="toggle-slider round"></span>
                                            </label>
                                        </div>
                                        </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td colspan="5" class="text-center">
                                    
                                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success btn-icon-text">
                                        Create <i class="typcn typcn-edit ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\project\Tugas-KLPN-2\Project-GAKKOU\resources\views\page\backend\User\index.blade.php ENDPATH**/ ?>