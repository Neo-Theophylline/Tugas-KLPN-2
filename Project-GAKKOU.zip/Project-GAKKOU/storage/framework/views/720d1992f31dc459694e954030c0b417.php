
<?php $__env->startSection('content'); ?>
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Create Account</h4>
                <form class="forms-sample" action="<?php echo e(route('users.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <label for="exampleInputName1">Nm</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="nama"
                            name="name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputName1">Email</label>
                        <input type="email" class="form-control" id="exampleInputName1" placeholder="email"
                            name="email">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail3">password</label>
                        <input type="password" class="form-control" id="exampleInputEmail3" placeholder="password"
                            name="password">
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-light">Cancel</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\project\Tugas-KLPN-2\Project-GAKKOU\resources\views\page\backend\User\create.blade.php ENDPATH**/ ?>