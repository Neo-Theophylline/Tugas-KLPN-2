<?php $__env->startSection('content'); ?>
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Edit Worker</h4>
                <form class="forms-sample" action="<?php echo e(route('admin.worker.update', $workers->id)); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label for="title">Name</label>
                        <input type="text" class="form-control" id="name" name="name"
                            value="<?php echo e(old('name', $workers->name)); ?>" placeholder="Name">
                    </div>

                    <div class="form-group">
                        <label for="subtitle">Position</label>
                        <input type="text" class="form-control" id="position" name="position"
                            value="<?php echo e(old('position', $workers->position)); ?>" placeholder="position">
                    </div>
                    <div class="form-group">
                        <label for="subtitle">Description</label>
                        <input type="text" class="form-control" id="discription" name="description"
                            value="<?php echo e(old('description', $workers->description)); ?>" placeholder="description">
                    </div>
                    <div class="form-group">
                        <label>File upload</label>
                        <input type="file" id="fileInput" style="display: none;" name="photo">
                        <div class="input-group col-xs-12">
                            <input type="text" class="form-control file-upload-info" disabled placeholder="Upload New Image">
                            <span class="input-group-append">
                                <button class="file-upload-browse btn btn-primary" type="button"
                                    onclick="document.getElementById('fileInput').click();">Upload</button>
                            </span>
                        </div>
                        <div>
                          <br>
                          <?php if($workers->photo): ?>
                            <img src="<?php echo e(asset('storage/' . $workers->photo)); ?>" alt="Current Photo" height="100">
                        <?php endif; ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a href="<?php echo e(route('admin.worker')); ?>" class="btn btn-light">Cancel</a>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\project\Tugas-KLPN-2\Project-GAKKOU\resources\views\page\backend\Worker\edit.blade.php ENDPATH**/ ?>