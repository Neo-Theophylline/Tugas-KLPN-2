<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card p-3">
            <h4 class="mb-3" style="font-size: 1.25rem; color: #495057;">Contact Detail</h4>
            <table class="table table-bordered mb-0" style="font-size: 0.875rem; color: #495057;">
                <tr>
                    <th>First Name</th>
                    <td><?php echo e($contact->firstname); ?></td>
                </tr>
                <tr>
                    <th>Last Name</th>
                    <td><?php echo e($contact->lastname); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo e($contact->email); ?></td>
                </tr>
                <tr>
                    <th>Phone Number</th>
                    <td><?php echo e($contact->phonenum); ?></td>
                </tr>
                <tr>
                    <th>Subject</th>
                    <td><?php echo e($contact->subject); ?></td>
                </tr>
                <tr>
                    <th>Message</th>
                    <td><?php echo e($contact->message); ?></td>
                </tr>
            </table>

            <a href="<?php echo e(route('admin.contact')); ?>" class="btn btn-secondary mt-3">Back to list</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\project\Tugas-KLPN-2\Project-GAKKOU\resources\views\page\backend\Contact\show.blade.php ENDPATH**/ ?>