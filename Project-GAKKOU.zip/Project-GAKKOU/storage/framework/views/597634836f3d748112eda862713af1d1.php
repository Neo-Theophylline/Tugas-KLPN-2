  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="sitename">RIZZ SCHOOL</h1>
      </a>


      <nav id="navmenu" class="navmenu">
        <ul>
      
          <li><a href="/" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a></li>
          <li><a href="about" class="<?php echo e(request()->is('about') ? 'active' : ''); ?>">About</a></li>
          <li><a href="services" class="<?php echo e(request()->is('services') ? 'active' : ''); ?>">Services</a></li>
          <li><a href="testimonials" class="<?php echo e(request()->is('testimonials') ? 'active' : ''); ?>">Testimonials</a></li>
          <li><a href="contact" class="<?php echo e(request()->is('contact') ? 'active' : ''); ?>">Contact us</a></li>
      
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header><?php /**PATH C:\project\Tugas-KLPN-2\Project-GAKKOU\resources\views\layout\frontend\navbar.blade.php ENDPATH**/ ?>